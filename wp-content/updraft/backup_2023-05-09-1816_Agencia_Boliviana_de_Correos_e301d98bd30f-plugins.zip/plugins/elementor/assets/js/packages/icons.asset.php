<?php
if(!defined('ABSPATH')){exit;}return['handle'=>'elementor-packages-icons','deps'=>['elementor-packages-ui','react',],];