__('Switch Device', 'elementor');
__('Desktop', 'elementor');
// translators: %s: Breakpoint label, %d: Breakpoint size.
__('%s (%dpx and up)', 'elementor');
// translators: %s: Breakpoint label, %d: Breakpoint size.
__('%s (up to %dpx)', 'elementor');